#ifndef TYPE_H_
#define TYPE_H_

#include <stdint.h>

const uint32_t kSendA = 0x000000010;
const uint32_t kSendB = 0x000000020;

#endif // TYPE_H_
